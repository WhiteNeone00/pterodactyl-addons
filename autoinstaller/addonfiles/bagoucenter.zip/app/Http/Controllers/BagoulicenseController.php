<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Exception;
use PDOException;
use Illuminate\View\View;
use Pterodactyl\Models\Bagoulicense;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Databases\Hosts\HostUpdateService;
use Pterodactyl\Http\Requests\Admin\DatabaseHostFormRequest;
use Pterodactyl\Services\Databases\Hosts\HostCreationService;
use Pterodactyl\Services\Databases\Hosts\HostDeletionService;
use Pterodactyl\Contracts\Repository\DatabaseRepositoryInterface;
use Pterodactyl\Contracts\Repository\LocationRepositoryInterface;
use Pterodactyl\Contracts\Repository\DatabaseHostRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class BagoulicenseController extends Controller
{
    protected $alert;

    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }
    /**
     * Display licensing system
     */
    public function index(): View
    {
        return view('admin.bagoulicense.index');
    }

    /**
     * Display license of the addon
     *
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     */
    public function license(string $addon): View
    {
        $dbaddon = Bagoulicense::where('addon', $addon)->first();
        return view('admin.bagoulicense.license', [
            'addon' => $addon,
            'enabled' => ($dbaddon)? $dbaddon['enabled'] : 0,
            'usage' => ($dbaddon) ? $dbaddon['usage_count'] : null ,
            'maxusage' => ($dbaddon) ? $dbaddon['maxusage'] : null,
            'license' => ($dbaddon) ? $dbaddon['license']: 'Your license',
        ]);
    }

    /**
     * Set a license
     *
     * @throws \Throwable
     */
    public function setlicense(Request $request, $addon): RedirectResponse
    {   
        $license = Http::accept('application/json')->get("https://api.whee.lol/license", [
            'id' => $request->license,
            'selectaddon' => $addon
        ])->object();
        if($license->message == 'No purchase found') {
            $this->alert->danger('License not found please contact me on discord')->flash();
            return redirect()->route('admin.bagoulicense.license', $addon);
        } else if($license->message == 'Too many license usage please contact me on discord') {
            $this->alert->danger('License are already used on too many panel please contact me on discord')->flash();
            return redirect()->route('admin.bagoulicense.license', $addon);
        } else if ($license->blacklisted) {
            if(Bagoulicense::where('addon', $addon)->exists()) {

                Bagoulicense::where('addon', $addon)->update(['license' => $request->license, 'usage_count' => 1, 'maxusage' => 1, 'enabled' => false]);
               } else {
                Bagoulicense::create(['addon' => $addon, 'license' => $request->license, 'usage_count' => 1, 'maxusage' => 1, 'enabled' => false]);
               }
            $this->alert->danger('You are BLACKLISTED (probably because of a paypal dispute)')->flash();
            return redirect()->route('admin.bagoulicense.license', $addon);
         } else if($license->message == 'Not the good addon') {
            $this->alert->danger('This license is not for this addon!')->flash();
            return redirect()->route('admin.bagoulicense.license', $addon);
        } else if($license->message == 'done' && $license->name == $addon && !$license->blacklisted) {
            if(Bagoulicense::where('addon', $addon)->exists()) {

                Bagoulicense::where('addon', $addon)->update(['license' => $request->license, 'usage_count' => $license->usage, 'maxusage' => $license->maxusage, 'enabled' => true]);
               } else {
                Bagoulicense::create(['addon' => $addon, 'license' => $request->license, 'usage_count' => $license->usage, 'maxusage' => $license->maxusage, 'enabled' => true]);
               }
        
               $this->alert->success('License updated sucessfully!')->flash();
               return redirect()->route('admin.bagoulicense.license', $addon);
        }

        $this->alert->danger('Error!')->flash();
        return redirect()->route('admin.bagoulicense.license', $addon);
    }

 /**
     * Rmove a license
     *
     * @throws \Throwable
     */
    public function removelicense($addon): RedirectResponse
    {   
            if(Bagoulicense::where('addon', $addon)->exists()) {
                $transaction = Bagoulicense::where('addon', $addon)->first();
                if(!$transaction) {
                    $this->alert->danger('No license found.')->flash();
                    return redirect()->route('admin.bagoulicense.license', $addon);
                }
                $transaction = $transaction['license'];
                $license = Http::delete("https://api.whee.lol/license?id=$transaction")->object();
                Bagoulicense::where('addon', $addon)->delete();
                $this->alert->success('License removed sucessfully')->flash();
                return redirect()->route('admin.bagoulicense.license', $addon);        
               } else {
                $this->alert->danger('No license found.')->flash();
                return redirect()->route('admin.bagoulicense.license', $addon);     
            }

    }
}
