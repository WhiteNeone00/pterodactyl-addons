<?php

namespace Pterodactyl\Http\Controllers\Admin\Bagou;

use Illuminate\View\View;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use Pterodactyl\Models\Bagoulicense;

class BagouVersionsController extends Controller
{
    public function index(): View
    {
        $licenses = Bagoulicense::all();
        return view('admin.bagoucenter.versions.index', ['licenses' => $licenses]);
    }
}
