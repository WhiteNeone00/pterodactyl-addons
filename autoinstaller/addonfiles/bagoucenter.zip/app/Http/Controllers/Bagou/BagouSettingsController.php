<?php

namespace Pterodactyl\Http\Controllers\Admin\Bagou;

use Illuminate\View\View;
use Pterodactyl\Http\Controllers\Controller;

class BagouSettingsController extends Controller
{
    public function index(): View
    {
        return view('admin.bagoucenter.settings.index');
    }
}
