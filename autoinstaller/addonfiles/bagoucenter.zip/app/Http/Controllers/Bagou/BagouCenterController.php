<?php

namespace Pterodactyl\Http\Controllers\Admin\Bagou;

use Illuminate\View\View;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;

class BagouCenterController extends Controller
{
    /**
     * Display bagou center main page
     */
    public function index(): View
    {
        $addonslist = Http::get('https://api.whee.lol/api/client/pterodactyl/addonsList')->json();
        return view('admin.bagoucenter.index', ['addonslist' => $addonslist]);
    }
}
