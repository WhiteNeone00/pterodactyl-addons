<?php

namespace Pterodactyl\Http\Controllers\Admin\Bagou;

use Illuminate\View\View;
use Pterodactyl\Models\Bagoulicense;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class BagouLicenseController extends Controller
{
    protected $alert;

    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }
    /**
     * Display licensing system
     */
    public function index(): View
    {
        try {
            $response = Http::timeout(10)->get('https://api.whee.lol/api/client/pterodactyl/addonsList');
            $addonslist = $response->successful() ? $response->json() : [];
        } catch (\Exception $e) {
            $addonslist = [];
        }
        $licenses = Bagoulicense::all();
        return view('admin.bagoucenter.license.index', ['addonslist' => $addonslist, 'licenses' => $licenses]);
    }

    /**
     * Display license of the addon
     *
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     */
    public function license(string $addon): View
    {
        try {
            $response = Http::timeout(10)->get('https://api.whee.lol/api/client/pterodactyl/addonsList');
            $addonslist = $response->successful() ? $response->json() : [];
        } catch (\Exception $e) {
            $addonslist = [];
        }
        $dbaddon = Bagoulicense::where('addon', $addon)->first();
        return view('admin.bagoucenter.license.license', [
            'addon' => $addon,
            'addonslist' => $addonslist,
            'enabled' => ($dbaddon)? $dbaddon['enabled'] : 0,
            'usage' => ($dbaddon) ? $dbaddon['usage'] : null ,
            'maxusage' => ($dbaddon) ? $dbaddon['maxusage'] : null,
            'license' => ($dbaddon) ? $dbaddon['license']: 'Your license',
        ]);
    }

    /**
     * Set a license
     *
     * @throws \Throwable
     */
    public function setlicense(Request $request, $addon): RedirectResponse
    {   
        $dbaddon = Bagoulicense::where('addon', $addon)->first();
        
        // If license is empty or same as before, just update the enabled status
        if (empty($request->license) || ($dbaddon && $dbaddon->license === $request->license)) {
            if ($dbaddon) {
                $dbaddon->update(['enabled' => $request->enabled]);
                $this->alert->success('License status updated successfully!')->flash();
            } else {
                $this->alert->danger('No license found for this addon')->flash();
            }
            return redirect()->route('admin.bagoucenter.license.addon', $addon);
        }

        try {
            $response = Http::timeout(10)->post("https://api.whee.lol/api/client/pterodactyl/license", [
                'id' => $request->license,
                'selectaddon' => $addon
            ]);
            
            $license = $response->json();
        } catch (\Exception $e) {
            $this->alert->danger('Error verifying license. Please try again later.')->flash();
            return redirect()->route('admin.bagoucenter.license.addon', $addon);
        }

        // Check response structure and handle all error cases
        if (!isset($license['status'])) {
            $this->alert->danger('Invalid response from license server.')->flash();
            return redirect()->route('admin.bagoucenter.license.addon', $addon);
        }

        // Handle error responses
        if ($license['status'] === 'error') {
            $message = $license['message'] ?? 'Unknown error';
            
            // Parse specific error messages
            if ($message === 'No license found.') {
                $this->alert->danger('License not found. Please contact support on discord')->flash();
            } elseif ($message === 'Too many usage.') {
                $this->alert->danger('License is already used on too many panels. Please contact support.')->flash();
            } elseif ($message === 'Not the good addon.') {
                $this->alert->danger('This license is not for this addon!')->flash();
            } elseif (strpos($message, 'blacklist') !== false || strpos($message, 'Blacklist') !== false) {
                $this->alert->danger('This license has been blacklisted. Please contact support.')->flash();
            } else {
                $this->alert->danger('Error: ' . $message)->flash();
            }
            return redirect()->route('admin.bagoucenter.license.addon', $addon);
        }

        // Handle successful response
        if ($license['status'] === 'success') {
            // Check for blacklisted status
            if (isset($license['blacklisted']) && $license['blacklisted']) {
                if(Bagoulicense::where('addon', $addon)->exists()) {
                    Bagoulicense::where('addon', $addon)->update(['license' => $request->license, 'usage' => 1, 'maxusage' => 1, 'enabled' => false]);
                } else {
                    Bagoulicense::create(['addon' => $addon, 'license' => $request->license, 'usage' => 1, 'maxusage' => 1, 'enabled' => false]);
                }
                $this->alert->danger('This license has been blacklisted. Please contact support.')->flash();
                return redirect()->route('admin.bagoucenter.license.addon', $addon);
            }
            
            // Check if license is for correct addon
            if (!isset($license['name']) || $license['name'] != $addon) {
                $this->alert->danger('This license is not for this addon!')->flash();
                return redirect()->route('admin.bagoucenter.license.addon', $addon);
            }
            
            // Update or create license record
            if(Bagoulicense::where('addon', $addon)->exists()) {
                Bagoulicense::where('addon', $addon)->update([
                    'license' => $request->license, 
                    'usage' => $license['usage'] ?? 0, 
                    'maxusage' => $license['maxusage'] ?? 0, 
                    'enabled' => $request->enabled
                ]);
            } else {
                Bagoulicense::create([
                    'addon' => $addon, 
                    'license' => $request->license, 
                    'usage' => $license['usage'] ?? 0, 
                    'maxusage' => $license['maxusage'] ?? 0, 
                    'enabled' => $request->enabled
                ]);
            }
            $this->alert->success('License updated successfully!')->flash();
            return redirect()->route('admin.bagoucenter.license.addon', $addon);
        }
        
        $this->alert->danger('Unknown error updating license')->flash();
        return redirect()->route('admin.bagoucenter.license.addon', $addon);
    }

    /**
     * Remove a license
     *
     * @throws \Throwable
     */
    public function removelicense($addon): RedirectResponse
    {   
        if(Bagoulicense::where('addon', $addon)->exists()) {
            $transaction = Bagoulicense::where('addon', $addon)->first();
            if(!$transaction) {
                $this->alert->danger('No license found.')->flash();
                return redirect()->route('admin.bagoucenter.license.addon', $addon);
            }
            $transaction = $transaction['license'];
            $license = Http::delete("https://api.whee.lol/license?id=$transaction")->object();
            Bagoulicense::where('addon', $addon)->delete();
            $this->alert->success('License removed successfully')->flash();
            return redirect()->route('admin.bagoucenter.license.addon', $addon);        
        } else {
            $this->alert->danger('No license found.')->flash();
            return redirect()->route('admin.bagoucenter.license.addon', $addon);     
        }
    }
}
