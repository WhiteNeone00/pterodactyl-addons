<?php

namespace Pterodactyl\Http\Controllers\Admin\Bagou;

use Illuminate\View\View;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use Pterodactyl\Models\Bagoulicense;

class BagouVersionsController extends Controller
{
    public function index(): View
    {
        try {
            $response = Http::timeout(10)->get('https://api.whee.lol/api/client/pterodactyl/addonsList');
            $addonslist = $response->successful() ? $response->json() : [];
        } catch (\Exception $e) {
            $addonslist = [];
        }
        $licenses = Bagoulicense::all();
        return view('admin.bagoucenter.versions.index', ['addonslist' => $addonslist, 'licenses' => $licenses]);
    }
}
