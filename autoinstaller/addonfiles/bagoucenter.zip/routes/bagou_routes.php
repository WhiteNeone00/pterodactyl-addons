<?php
// Bagoucenter Routes from admin.php
// Location: /admin/bagoucenter

Route::group(['prefix' => 'bagoucenter'], function () {
    Route::get('/', [Admin\Bagou\BagouCenterController::class, 'index'])->name('admin.bagoucenter');
    Route::get('/license/', [Admin\Bagou\BagouLicenseController::class, 'index'])->name('admin.bagoucenter.license');
    Route::get('/license/{addon}', [Admin\Bagou\BagouLicenseController::class, 'license'])->name('admin.bagoucenter.license.addon');
    Route::get('/versions', [Admin\Bagou\BagouVersionsController::class, 'index'])->name('admin.bagoucenter.versions');
    Route::get('/settings', [Admin\Bagou\BagouSettingsController::class, 'index'])->name('admin.bagoucenter.settings');
    Route::get('/settings/mcversions', [Admin\Bagou\BagouMcVersionsController::class, 'index'])->name('admin.bagoucenter.settings.addon.mcversions');
    Route::post('/settings/mcversions/add', [Admin\Bagou\BagouMcVersionsController::class, 'add'])->name('admin.bagoucenter.settings.mcversions.add');
    Route::delete('/settings/mcversions/{id}', [Admin\Bagou\BagouMcVersionsController::class, 'delete'])->name('admin.bagoucenter.settings.mcversions.delete');
    Route::get('/settings/subdomain', [Admin\Bagou\BagouSettingsController::class, 'index'])->name('admin.bagoucenter.settings.subdomain.index');
    Route::get('/cloud', [Admin\Bagou\BagouSettingsController::class, 'index'])->name('admin.bagoucenter.cloud');
    Route::get('/mcplugins', [Admin\Bagou\BagouSettingsController::class, 'index'])->name('admin.bagoucenter.mcplugins');
    Route::get('/modpacks', [Admin\Bagou\BagouSettingsController::class, 'index'])->name('admin.bagoucenter.modpacks');
    Route::get('/support', [Admin\Bagou\BagouSupportController::class, 'index'])->name('admin.bagoucenter.support');
});
